#pragma once

namespace KashipanEngine {

struct LineOption {
    int type = 0;
};

} // KashipanEngine